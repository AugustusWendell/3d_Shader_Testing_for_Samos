using System;
using UnityEngine;

namespace RuntimeGizmos
{
	public class TargetInfo
	{
		public Vector3 centerPivotPoint;
	}
}
